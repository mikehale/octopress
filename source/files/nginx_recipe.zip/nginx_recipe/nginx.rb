Capistrano.configuration(:must_exist).load do
  
  task :apache_install do
    install_nginx #install nginx, not apache as part of install_rails_stack
  end
  
  task :setup_web, :roles => :web  do
    configure_nginx
  end

  task :start_nginx, :roles => :web do
    send(run_method, "/etc/init.d/nginx start")
  end
    
  task :restart_nginx, :roles => :web do
    send(run_method, "/etc/init.d/nginx restart")
  end
    
  task :stop_nginx, :roles => :web do
    send(run_method, "/etc/init.d/nginx stop")
  end
    
  task :install_nginx do
    version = 'nginx-0.5.32'
    file = "#{version}.tar.gz"
    set :src_package, {
      :file => file,   
      :md5sum => '0088269b8a59a146b0ba9c9ee29853bb  #{file}', 
      :dir => version,  
      :url => "http://sysoev.ru/nginx/#{file}",
      :unpack => "tar zxf #{file};",
      :configure => %w(
        ./configure
        --with-http_ssl_module 
        --prefix=/usr/nginx 
        --sbin-path=/usr/sbin 
        --conf-path=/etc/nginx/nginx.conf 
        ;
        ).reject{|arg| arg.match '#'}.join(' '),
      :make => 'make;',
      :install => 'make install;'
    }
    apt.install( {:base => %w(libpcre3-dev libssl-dev)}, :stable )
    deprec.download_src(src_package, src_dir)
    deprec.install_from_src(src_package, src_dir)

    deprec.render_template_to_file('init.d.nginx', '/etc/init.d/nginx', templates_dir)
    send(run_method, "chmod a+x /etc/init.d/nginx")
    send(run_method, "update-rc.d nginx defaults")
  end
  
  task :configure_nginx do
    deprec.render_template_to_file('nginx', '/etc/nginx/nginx.conf', templates_dir)
  end
  
end